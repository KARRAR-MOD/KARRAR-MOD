package com.karrarmod.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class MainActivity : Activity() {
    private val gold = 0xFFD6A84B.toInt()
    private val dark = 0xFF101010.toInt()
    private val panel = 0xFF1D1D1D.toInt()
    private lateinit var list: LinearLayout
    private lateinit var status: TextView
    private val filesDirMods by lazy { File(filesDir, "mods").apply { mkdirs() } }
    private val pickFiles = 100
    private val createBackup = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    private fun render() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 24, 20, 16)
            setBackgroundColor(dark)
            layoutDirection = LinearLayout.LayoutDirection.RTL
        }
        val title = TextView(this).apply {
            text = "KARRAR MOD"
            textSize = 28f
            setTextColor(gold)
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "مدير ملفاتك المحلي"
            textSize = 14f
            setTextColor(0xFFBBBBBB.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 4, 0, 18)
        }
        root.addView(title)
        root.addView(subtitle)
        root.addView(actionButton("استيراد ملفات PAK / LUA") { openFilePicker() })
        root.addView(actionButton("إنشاء نسخة احتياطية ZIP") { makeBackup() })
        root.addView(actionButton("تشغيل PUBG Mobile العالمية") { launchPubg() })
        status = TextView(this).apply {
            setTextColor(gold); textSize = 13f; setPadding(4, 14, 4, 8)
        }
        root.addView(status)
        val heading = TextView(this).apply {
            text = "الملفات المستوردة"; setTextColor(-1); textSize = 18f
            setPadding(4, 12, 4, 8)
        }
        root.addView(heading)
        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        refreshList()
    }

    private fun actionButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        setTextColor(dark)
        setBackgroundColor(gold)
        isAllCaps = false
        textSize = 15f
        setOnClickListener { action() }
        val p = LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT)
        p.setMargins(0, 5, 0, 5)
        layoutParams = p
    }

    private fun openFilePicker() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("*/*"))
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        startActivityForResult(i, pickFiles)
    }

    @Deprecated("Deprecated by Android API; retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickFiles && resultCode == RESULT_OK && data != null) {
            val uris = mutableListOf<Uri>()
            data.clipData?.let { clip -> for (n in 0 until clip.itemCount) uris.add(clip.getItemAt(n).uri) }
            data.data?.let { if (uris.isEmpty()) uris.add(it) }
            var ok = 0; var skipped = 0; var failed = 0
            uris.forEach { uri ->
                try {
                    val name = queryName(uri) ?: "import_${System.currentTimeMillis()}"
                    if (!name.lowercase().endsWith(".pak") && !name.lowercase().endsWith(".lua")) {
                        skipped++; return@forEach
                    }
                    val safe = name.replace(Regex("[^A-Za-z0-9._-]"), "_")
                    val out = File(filesDirMods, safe)
                    contentResolver.openInputStream(uri)?.use { input ->
                        out.outputStream().use { output -> input.copyTo(output) }
                    } ?: throw IllegalStateException("تعذر فتح الملف")
                    ok++
                } catch (_: Exception) { failed++ }
            }
            status.text = "تم الاستيراد: $ok  |  تم التخطي: $skipped  |  فشل: $failed"
            refreshList()
        } else if (requestCode == createBackup && resultCode == RESULT_OK) {
            data?.data?.let { uri ->
                try {
                    contentResolver.openOutputStream(uri)?.use { stream ->
                        ZipOutputStream(BufferedOutputStream(stream)).use { zip ->
                            filesDirMods.listFiles()?.filter { it.isFile }?.forEach { file ->
                                zip.putNextEntry(ZipEntry(file.name))
                                BufferedInputStream(file.inputStream()).use { it.copyTo(zip) }
                                zip.closeEntry()
                            }
                        }
                    } ?: throw IllegalStateException("لم يتم إنشاء الملف")
                    status.text = "تم إنشاء النسخة الاحتياطية بنجاح"
                } catch (e: Exception) { status.text = "فشل إنشاء النسخة: ${e.message ?: "خطأ"}" }
            }
        }
    }

    private fun queryName(uri: Uri): String? {
        contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) return it.getString(0)
        }
        return null
    }

    private fun refreshList() {
        list.removeAllViews()
        val items = filesDirMods.listFiles()?.filter { it.isFile }?.sortedBy { it.name } ?: emptyList()
        status.text = "عدد الملفات: ${items.size}"
        if (items.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "لا توجد ملفات بعد"; setTextColor(0xFFAAAAAA.toInt()); setPadding(8, 12, 8, 12)
            })
        }
        items.forEach { file ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(12, 10, 12, 10); setBackgroundColor(panel)
            }
            val info = TextView(this).apply {
                text = "${file.name}\n${formatSize(file.length())}"
                setTextColor(-1); textSize = 13f
            }
            row.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
            val delete = Button(this).apply {
                text = "حذف"; isAllCaps = false; setTextColor(gold)
                setOnClickListener {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("حذف الملف")
                        .setMessage("هل تريد حذف ${file.name}؟")
                        .setNegativeButton("إلغاء", null)
                        .setPositiveButton("حذف") { _, _ ->
                            if (file.delete()) status.text = "تم حذف الملف" else status.text = "تعذر حذف الملف"
                            refreshList()
                        }.show()
                }
            }
            row.addView(delete)
            val lp = LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, 4, 0, 4)
            list.addView(row, lp)
        }
    }

    private fun makeBackup() {
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/zip"
            putExtra(Intent.EXTRA_TITLE, "KARRAR_MOD_backup.zip")
        }
        startActivityForResult(i, createBackup)
    }

    private fun launchPubg() {
        val launch = packageManager.getLaunchIntentForPackage("com.tencent.ig")
        if (launch != null) startActivity(launch)
        else Toast.makeText(this, "PUBG Mobile العالمية غير مثبتة", Toast.LENGTH_LONG).show()
    }

    private fun formatSize(bytes: Long): String =
        if (bytes < 1024) "$bytes B" else if (bytes < 1024 * 1024)
            String.format("%.1f KB", bytes / 1024.0) else String.format("%.1f MB", bytes / (1024.0 * 1024.0))
}
